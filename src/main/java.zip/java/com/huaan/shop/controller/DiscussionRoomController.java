package com.huaan.shop.controller;

import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/discussionRoom")
public class DiscussionRoomController {

	// @Autowired
	// private CommunityAnnouncementService communityAnnounceService;

	@RequestMapping("/getDiscussion")
	public @ResponseBody String getDiscussion() {
		// List<CommunityAnnouncement> cas =
		// communityAnnounceService.getCommunityAnnouncement();
		return null;
	}

	@RequestMapping(value = "getDiscussionComments/{discussionID}")
	public @ResponseBody String getgetDiscussionComments(@PathVariable int communityAnnouncementID) {

		// get the comments from database

		return null;
	}
	
	@RequestMapping(value = "getDiscussionLike/{discussionID}")
	public @ResponseBody String getDiscussionLike(@PathVariable int communityAnnouncementID) {

		// get the like from database

		return null;
	}

	@RequestMapping(value = "setDiscussionLike", method = RequestMethod.POST)
	public @ResponseBody String setDiscussionLike(@RequestBody Map<String, String> jsonData) {
		String phoneNo = jsonData.get("phoneNo");

		return null;
	}

	@RequestMapping(value = "setDiscussionComment", method = RequestMethod.POST)
	public @ResponseBody String setDiscussionComment(@RequestBody Map<String, String> jsonData) {
		String phoneNo = jsonData.get("phoneNo");
		String comment = jsonData.get("comment");

		return null;
	}
}
