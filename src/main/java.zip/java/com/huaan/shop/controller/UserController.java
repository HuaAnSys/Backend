package com.huaan.shop.controller;

import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;
import com.huaan.shop.model.UserInfo;
import com.huaan.shop.service.UserService;

/**
 * 
 * @author Tony
 * @version 1.0
 */
@Controller
@RequestMapping("/user")
public class UserController {

	private static Logger logger = Logger.getLogger(UserController.class);

	@Autowired
	private UserService userService;

	@RequestMapping("/showInfo/{userId}")
	public String showUserInfo(ModelMap modelMap, @PathVariable int userId) {
		UserInfo userInfo = userService.getUserById(userId);
		modelMap.addAttribute("userInfo", userInfo);
		return "/user/showInfo";
	}

	@RequestMapping("/showInfos")
	public @ResponseBody Object showUserInfos() {
		List<UserInfo> userInfos = userService.getUsers();
		return userInfos;
	}

	@RequestMapping(value = "/registerUser", produces = "application/json;charset=UTF-8", method = RequestMethod.POST)
	public @ResponseBody String registerUser(@RequestBody Map<String, String> jsonData) {
		logger.info("enter registerUser method.");

		String retStr = "{}";
		System.out.println("The jsonData is" + jsonData);
		
		
		//chceck if user exist, you can reuse userService.getUserById(userId)
		
		//logic to insert to database
		UserInfo userInfo = new UserInfo();
		
		userInfo.setUname(jsonData.get("userName"));
		userInfo.setUnumber(Integer.valueOf(jsonData.get("Unumber")));
		
		
		
		userService.insert(userInfo);
		
		JSONObject jsonObj = new JSONObject();
		jsonObj.put("result", "success");

		return jsonObj.toString();
	}
}
