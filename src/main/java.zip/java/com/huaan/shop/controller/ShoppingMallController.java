package com.huaan.shop.controller;

import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * 
 * @author Tony
 * @version 1.0
 */
@Controller
@RequestMapping("/shoppingmall")
public class ShoppingMallController {

	private static Logger logger = Logger.getLogger(ShoppingMallController.class);
	
//	@Autowired
//	private ProductService productSerivce;
	
//	@Autowired
//	private CategoryService categoryService;
	
	@RequestMapping(value = "getHotProducts" , method = RequestMethod.GET)
	public @ResponseBody String getHotProducts(){
		logger.info("enter into getHotProducts method");
//		List<Product> hotProducts = productSerivce.getHotProducts();
		
		return null;
	}
	
	@RequestMapping(value = "getCategory" , method = RequestMethod.GET)
	public @ResponseBody String getCategory(){
		logger.info("enter into getHotProducts method");
		
//		List<Category> category = categoryService.getCategory();
		
		return null;
	}
	
	@RequestMapping(value = "getProduct/{productID}" , method = RequestMethod.POST)
	public @ResponseBody String getProductByID(@RequestBody Map<String, String> jsonData){
		logger.info("enter into getProductByID method");
		
		int productID = Integer.valueOf(jsonData.get("productID"));
		
//		List<Category> category = productSerivce.getProductByID(productID);
		
		return null;
	}
	
	@RequestMapping(value = "getProducts/{categoryID}" , method = RequestMethod.POST)
	public @ResponseBody String getcategoryID(@RequestBody Map<String, String> jsonData){
		logger.info("enter into getcategoryID method");
		
		int productID = Integer.valueOf(jsonData.get("categoryID"));
		
//		List<Category> category = productSerivce.getProductByID(productID);
		
		return null;
	}
	
//	@Autowired
//	private UserService userService;

//	@RequestMapping("/showInfo/{userId}")
//	public String showUserInfo(ModelMap modelMap, @PathVariable int userId) {
//		UserInfo userInfo = userService.getUserById(userId);
//		modelMap.addAttribute("userInfo", userInfo);
//		return "/user/showInfo";
//	}
//
//	@RequestMapping("/showInfos")
//	public @ResponseBody Object showUserInfos() {
//		List<UserInfo> userInfos = userService.getUsers();
//		return userInfos;
//	}
//
//	@RequestMapping(value = "/registerUser", produces = "application/json;charset=UTF-8", method = RequestMethod.POST)
//	public @ResponseBody String registerUser(@RequestBody Map<String, String> jsonData) {
//		logger.info("enter registerUser method.");
//
//		String retStr = "{}";
//		System.out.println("The jsonData is" + jsonData);
//		
//		
//		//chceck if user exist, you can reuse userService.getUserById(userId)
//		
//		//logic to insert to database
//		UserInfo userInfo = new UserInfo();
//		
//		userInfo.setUname(jsonData.get("userName"));
//		userInfo.setUnumber(Integer.valueOf(jsonData.get("Unumber")));
//		
//		
//		
//		userService.insert(userInfo);
//		
//		JSONObject jsonObj = new JSONObject();
//		jsonObj.put("result", "success");
//
//		return jsonObj.toString();
//	}
}
