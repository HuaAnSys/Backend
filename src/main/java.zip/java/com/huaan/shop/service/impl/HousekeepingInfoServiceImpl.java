package com.huaan.shop.service.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.huaan.shop.model.HousekeepingInfo;
import com.huaan.shop.service.HousekeepingInfoService;

@Service("hoursekeepingInfoService")
public class HousekeepingInfoServiceImpl implements HousekeepingInfoService {

	@Override
	public List<HousekeepingInfo> getAllHousekeepingInfo() {
		// TODO Auto-generated method stub
		return null;
	}
}
