package com.huaan.shop.service;

import java.util.List;

import com.huaan.shop.model.HousekeepingInfo;

public interface HousekeepingInfoService {
	List<HousekeepingInfo> getAllHousekeepingInfo();
}
